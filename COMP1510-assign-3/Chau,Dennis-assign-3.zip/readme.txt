Dennis Yick Jing Chau, A00920445, 1B, Nov 20, 2014

This assignment is 100% complete.


------------------------
Question one (Household) status:

Complete

------------------------
Question two (Guess) status:

Complete

------------------------
Question three (TestStudent and supporting classes) status:

Complete

------------------------
Question four (TestCourse and supporting classes) status:

Complete

------------------------
